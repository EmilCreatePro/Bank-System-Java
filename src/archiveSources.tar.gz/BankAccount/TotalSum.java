package BankAccount;

public interface TotalSum {
    public Double getSumFromAccount();
}
