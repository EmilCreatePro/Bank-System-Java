package Bank;

public class ConcreteBank extends  IBank{

    public ConcreteBank(Integer bankCode)
    {
        super(bankCode);
    }
}
