package CustomExceptions;

public class NotRONAccountException extends Exception
{
    public NotRONAccountException(String msg)
    {
        super(msg);
    }
}
