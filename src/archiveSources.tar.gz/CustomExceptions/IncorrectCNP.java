package CustomExceptions;

public class IncorrectCNP extends Exception {
    public IncorrectCNP(String message)
    {
        super(message);
    }
}
