package CustomExceptions;

public class NegativeSum extends Exception{
    public NegativeSum(String message)
    {
        super(message);
    }
}
