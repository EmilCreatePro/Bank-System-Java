package CustomExceptions;

public class NoClientsException extends Exception
{
    public NoClientsException(String msg)
    {
        super(msg);
    }
}
